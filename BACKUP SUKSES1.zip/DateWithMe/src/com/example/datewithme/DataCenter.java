package com.example.datewithme;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DataCenter extends SQLiteOpenHelper {
	
	private static final String DATABASE_NAME = "crud_panen.db";
	private static final int DATABASE_VERSION = 1;
	public DataCenter(Context context) {
		super(context, DATABASE_NAME, null, DATABASE_VERSION);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void onCreate(SQLiteDatabase db){
		// TODO Auto-generated method stub
		String sql = "create table datapanen(kode integer primary key, nama text null, alamat text null, jenis text null, jmlhudang text null, jmlhbandeng text null, tglmasuk text null);";
		Log.d("Data", "onCreate: " + sql);
		db.execSQL(sql);
		sql = "INSERT INTO datapanen (kode, nama, alamat, jenis, jmlhudang, jmlhbandeng, tglmasuk) VALUES ('001', 'Ghazali', 'Desa Windu', 'Udang & Bandeng','20 Rean','7 Rean','20-mei-2015');";
		db.execSQL(sql);
		sql = "INSERT INTO datapanen (kode, nama, alamat, jenis, jmlhudang, jmlhbandeng, tglmasuk) VALUES ('002', 'Bedjo', 'Desa Kuro', 'Udang','40 Rean','0 Rean','10-mei-2015');";
		db.execSQL(sql);
		sql = "INSERT INTO datapanen (kode, nama, alamat, jenis, jmlhudang, jmlhbandeng, tglmasuk) VALUES ('003', 'Shomat', 'Desa Kuro no.2', 'Bandeng','0 Rean','17 Rean','17-mei-2015');";
		db.execSQL(sql);
		sql = "INSERT INTO datapanen (kode, nama, alamat, jenis, jmlhudang, jmlhbandeng, tglmasuk) VALUES ('004', 'ali', 'Desa Jatirenggo', 'Udang & Bandeng','15 Rean','3 Rean','18-mei-2015');";
		db.execSQL(sql);
	}
	@Override
	public void onUpgrade(SQLiteDatabase arg0, int arg1, int arg2) {
		// TODO Auto-generated method stub
	}
}