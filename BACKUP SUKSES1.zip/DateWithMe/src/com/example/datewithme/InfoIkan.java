package com.example.datewithme;



import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;

public class InfoIkan extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.info_ikan);
	}
	public void infoudang(View v){
		Intent IU = new Intent(this, InfoUdang.class);
    	startActivity(IU);
	}
	public void infobandeng(View v){
		Intent IB = new Intent(this, InfoBandeng.class);
    	startActivity(IB);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.info_ikan, menu);
		return true;
	}

}
