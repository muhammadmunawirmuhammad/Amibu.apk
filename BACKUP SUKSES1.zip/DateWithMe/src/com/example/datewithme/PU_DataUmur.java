package com.example.datewithme;


import java.util.ArrayList;
import java.util.List;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class PU_DataUmur extends SQLiteOpenHelper {
	private static final String DATABASE_NAME = "dbUmur";
	public static final String ID	 = "_id";
	public static final String UMUR = "Umur";
	
	public PU_DataUmur(Context context) {
		super(context, DATABASE_NAME, null, 1);
	}
	
	public void createTable(SQLiteDatabase db) {
		db.execSQL("DROP TABLE IF EXISTS Umur");
		db.execSQL("CREATE TABLE if not exists Umur (_id INTEGER PRIMARY KEY AUTOINCREMENT, umur varchar(50));");
	}
	
	public void generateData(SQLiteDatabase db) {
		ContentValues cv = new ContentValues();
		cv.put(UMUR, "1-10 Hari");
		db.insert("Umur", UMUR, cv);
		
		cv.put(UMUR, "11-15 Hari");
		db.insert("Umur", UMUR, cv);
		
		//cv.put(PAKET, "Night");
		//db.insert("Paket", PAKET, cv);
		
		//cv.put(PAKET, "Half Day or Less");
		//db.insert("Paket", PAKET, cv);
		
		//cv.put(PAKET, "Tailored");
		//db.insert("Paket", PAKET, cv);
	}
	
	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		//TODO Auto-generated method stub
	}
	
	@Override
	public void onCreate(SQLiteDatabase db) {
		//TODO Auto-generated method sub	
	}
	
	/**
     * Getting all labels
     * returns list of labels
     * */
    public List<String> getAllLabels(){
        List<String> labels = new ArrayList<String>();
 
        // Select All Query
        String selectQuery = "SELECT * FROM Umur";
 
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
 
        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                labels.add(cursor.getString(1));
            } while (cursor.moveToNext());
        }
 
        // closing connection
        //cursor.close();
        //db.close();
 
        // returning lables
        return labels;
    }
}