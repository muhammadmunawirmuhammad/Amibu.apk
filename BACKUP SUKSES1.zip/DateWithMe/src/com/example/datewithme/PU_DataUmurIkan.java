package com.example.datewithme;


import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class PU_DataUmurIkan extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "dbUmurIkan";
	public static final String IKAN = "ikan";
	public static final String UMUR  = "umur";
	public static final String NAMA   = "nama";
	public static final String IMAGE  = "image";
	public static final String KETERANGAN = "keterangan";
	public static final String DETAIL = "detail";
	
	public PU_DataUmurIkan(Context context) {
		super(context, DATABASE_NAME, null, 1);
	}
	
	public void createTable(SQLiteDatabase db) {
		db.execSQL("DROP TABLE IF EXISTS UmurIkan");
		db.execSQL("CREATE TABLE if not exists UmurIkan (id INTEGER PRIMARY KEY AUTOINCREMENT, ikan varchar(50), umur varchar(50), nama varchar(50), image varchar(50), keterangan TEXT, detail TEXT);");
	}
	
	public void generateData(SQLiteDatabase db) {
		ContentValues cv = new ContentValues();
		cv.put(IKAN, "Udang");
		cv.put(UMUR, "1-10 Hari");
		cv.put(NAMA, "USIA 1-10 Hari");
		cv.put(IMAGE, "tanah_lot.png");
		cv.put(KETERANGAN, "Pada Usia 1-10 Hari Udang mengalami masa adaptasi");
		cv.put(DETAIL, "Udang sangat rentang mati dikarenakan usia udang yang mengalami seleksi alam BLA-BLA-BLAAA");
		db.insert("UmurIkan", IKAN, cv);
		
		cv.put(IKAN, "Udang");
		cv.put(UMUR, "11-15 Hari");
		cv.put(NAMA, "USIA 11-15 Hari");
		cv.put(IMAGE, "besakih.png");
		cv.put(KETERANGAN, "Pada usia ini udang sudah beradaptasi dengan lingkungan sekitar.");
		cv.put(DETAIL, "Udang Membutuhkan BLA-BLA-BLAAAA.");
		db.insert("UmurIkan", IKAN, cv);
		
		//cv.put(NEGARA, "Indonesia");
		//cv.put(PAKET, "Full Day");
		//cv.put(NAMA, "Kintamani � Ubud Tour");
		//cv.put(IMAGE, "ubud.png");
		//cv.put(KETERANGAN, "Ubud, merupakan desa seni di Bali. Banyak seniman terlahir di sini, sehingga merupakan pusat dari museum seni lukis di Bali. Ubud memiliki lingkungan yang sejuk dan asri dan memiliki aura yang kuat bagi seniman di Bali.");
		//cv.put(DETAIL, "");
		//db.insert("PaketWisata", NEGARA, cv);
		
		cv.put(IKAN, "Bandeng");
		cv.put(UMUR, "1-10 Hari");
		cv.put(NAMA, "Usia Pertama");
		cv.put(IMAGE, "danau_toba.png");
		cv.put(KETERANGAN, "Danau Toba memiliki wisata alam yang luar biasa, wisata spiritual, wisata sejarah, atau pun wisata arsitektur dan kuliner. Suasana yang sejuk dan menyegarkan, hamparan air yang jernih, serta pemandangan yang memesona dengan pegunungan hijau.");
		cv.put(DETAIL, "");
		db.insert("UmurIkan", IKAN, cv);
		
		//cv.put(NEGARA, "Australia");
		//cv.put(PAKET, "Night");
		//cv.put(NAMA, "Tour Gold Coast");
		//cv.put(IMAGE, "gold_coast.png");
		//cv.put(KETERANGAN, "Tour Gold Coast provides certified eco tours and activities for conference, events, social and student groups. Founders of the renowned and popular Natural Bridge Glow Worm Tour, Tour Gold Coast pioneered eco-tours on the Gold Coast. Tour Gold Coast is dedicated to providing visitors to the Gold Coast with top quality touring experiences. Enthusiastic local guides are all trained by certified EcoGuides and committed to providing quality nature tourism and ecotourism experiences in a safe, culturally sensitive and environmentally sustainable manner. Tour Gold Coast is an Advance Eco-certified operator and a Climate Friendly Business. They support Greenfleet and plant native trees with donations from tour participants to offset their carbon emissions.");
		//cv.put(DETAIL, "");
		//db.insert("PaketWisata", NEGARA, cv);
		
		//cv.put(NEGARA, "Australia");
		//cv.put(PAKET, "Extended");
		//cv.put(NAMA, "Coach Tours Tasmania");
		//cv.put(IMAGE, "coach_tours_tasmania.png");
		//cv.put(KETERANGAN, "Groups Tasmania and Couch Tours Tasmania offer a range of coach tours across Tasmania. Coach Tours Tasmania are proud to offer a range of day tours ex-Launceston which include all that Tasmania is famous for. Enjoy a comprehensive tour from our program ranging from the full day tours to some of Tasmania's iconic regions to the shorter half day options of the local area. We operate on a �you choose� system which means the first person to book for a day chooses the tour.");
		//cv.put(DETAIL, "");
		//db.insert("PaketWisata", NEGARA, cv);
		
		//cv.put(NEGARA, "Singapura");
		//cv.put(PAKET, "Night");
		//cv.put(NAMA, "Night Safari");
		//cv.put(IMAGE, "night_safari.png");
		//cv.put(KETERANGAN, "Night Safari adalah salah satu daya tarik seperti di Singapura yang merupakan salah satu jenis di seluruh Asia. Ini adalah pengalaman yang indah untuk pergi untuk safari malam dan melihat hewan malam di alam sekitarnya. Hal ini layak untuk menikmati safari malam yang pasti akan membuat Tour Singapura dan pengalaman untuk harta dan nikmati selamanya.");
		//cv.put(DETAIL, "");
		//db.insert("PaketWisata", NEGARA, cv);
		
		//cv.put(NEGARA, "Singapura");
		//cv.put(PAKET, "Extended");
		//cv.put(NAMA, "SEA Aquarium Singapura");
		//cv.put(IMAGE, "sea_aquarium.png");
		//cv.put(KETERANGAN, "S.E.A. Aquarium Singapore dan lihat keindahan dunia laut serta daya magic SEA Aquarium Singapura yang terlihat melalui jendela Aquarium Laut terbesar di Dunia, Singapore. Dengan lebih dari 800 spesies hewan laut Anda dapat melihat Ikan Pari Manta Besar, Ikan Kerapu Besar, Ikan Napoleon, dan Ikan raksasa lainnya di laut.");
		//cv.put(DETAIL, "");
		//db.insert("PaketWisata", NEGARA, cv);
		
		//cv.put(NEGARA, "Singapura");
		//cv.put(PAKET, "Extended");
		//cv.put(NAMA, "Universal Studio");
		//cv.put(IMAGE, "universal_studio.png");
		//cv.put(KETERANGAN, "Universal Studios Singapore merupakan sebuah taman rekreasi dimana pengunjung dapat sepenuhnya masuk ke dalam suasana dunia film dan pembuatan film. Wahana State-Of-The-Art, meperlihatkan atraksi yang diperuntukkan untuk semua usia, dari wahana menyenangkan bagi anak-anak untuk naik mendebarkan, untuk remaja hingga orang dewasa.");
		//cv.put(DETAIL, "");
		//db.insert("PaketWisata", NEGARA, cv);
	}
	
	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		//TODO Auto-generated method stub
	}
	
	@Override
	public void onCreate(SQLiteDatabase db) {
		//TODO Auto-generated method sub		
	}
}
