package com.example.datewithme;



import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

public class PU_DetailUmur extends Activity {
	private SQLiteDatabase db = null;
	private PU_DataUmurIkan dataDB = null;
	private Cursor cursor = null;
	private String id = null;
	private TextView judul, isi, detail, imageText;
	private ImageView image;
	
	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.detail);
        
        judul  = (TextView) findViewById(R.id.title);
        isi	   = (TextView) findViewById(R.id.keterangan);
        detail = (TextView) findViewById(R.id.detail);
        imageText = (TextView) findViewById(R.id.txtImage);
        image  = (ImageView) findViewById(R.id.list_image);
        
        dataDB = new PU_DataUmurIkan(this);
	    db = dataDB.getWritableDatabase();
	    
	    getPaketDetail();
    }
    
    public void getPaketDetail() {
    	Bundle b = getIntent().getExtras(); 
    	id = b.getString("ID");
    	
    	try {
		    cursor = db.rawQuery("SELECT * " + "FROM UmurIkan where id = '" + id + "';", null);
		    if (cursor.getCount() > 0) {
		    	int indexJudul  = cursor.getColumnIndex("nama");
		    	int indexIsi    = cursor.getColumnIndex("keterangan");
		    	int indexDetail = cursor.getColumnIndex("detail");
		    	int indexImage  = cursor.getColumnIndex("image");
		    	
		    	cursor.moveToFirst();
				do {
					String Judul  = cursor.getString(indexJudul);
					String Isi    = cursor.getString(indexIsi);
					String Detail = cursor.getString(indexDetail);
					String Image  = cursor.getString(indexImage);
					
					judul.setText(Judul);
					isi.setText(Isi); 
					detail.setText(Detail);
					imageText.setText(Image);
					if (Image.equals("tanah_lot.png")) {
			        	image.setImageResource(R.drawable.tanah_lot);
			        } else if (Image.equals("ubud.png")) {
			        	image.setImageResource(R.drawable.ubud);
			        } else if (Image.equals("gold_coast.png")) {
			        	image.setImageResource(R.drawable.gold_coast);
			        } else if (Image.equals("coach_tours_tasmania.png")) {
			        	image.setImageResource(R.drawable.coach_tours_tasmania);
			        } else if (Image.equals("night_safari.png")) {
			        	image.setImageResource(R.drawable.night_safari);
			        } else if (Image.equals("danau_toba.png")) {
			        	image.setImageResource(R.drawable.danau_toba);
			        } else if (Image.equals("besakih.png")) {
			        	image.setImageResource(R.drawable.besakih);
			        } else if (Image.equals("sea_aquarium.png")) {
			        	image.setImageResource(R.drawable.sea_aquarium);
			        } else if (Image.equals("universal_studio.png")) {
			        	image.setImageResource(R.drawable.universal_studio);
			        }
					
					cursor.moveToNext();
				} while (!cursor.isAfterLast());
		    }
	    } finally {
			if (cursor != null) {
				cursor.close();
			}
		}
    }
}
