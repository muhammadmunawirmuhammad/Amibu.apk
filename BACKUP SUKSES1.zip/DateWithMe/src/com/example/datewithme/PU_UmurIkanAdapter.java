package com.example.datewithme;


import java.util.ArrayList;
import java.util.HashMap;


import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class PU_UmurIkanAdapter extends BaseAdapter {
    private Activity activity;
    private ArrayList<HashMap<String, String>> data;
    private static LayoutInflater inflater=null;
    HashMap<String, String> tipss;
    
    public PU_UmurIkanAdapter(Activity a, ArrayList<HashMap<String, String>> d) {
        activity = a;
        data=d;
        inflater = (LayoutInflater)activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    public int getCount() {
        return data.size();
    }

    public Object getItem(int position) {
        return position;
    }

    public long getItemId(int position) {
        return position;
    }
    
    public View getView(int position, View convertView, ViewGroup parent) {
        View vi=convertView;
        if(convertView==null)
            vi = inflater.inflate(R.layout.list_row, null);
 
        TextView id	   = (TextView)vi.findViewById(R.id.id);
        TextView title = (TextView)vi.findViewById(R.id.title); 
        TextView keterangan = (TextView)vi.findViewById(R.id.keterangan);
        TextView txtImage   = (TextView)vi.findViewById(R.id.txtImage);
        ImageView thumb_image =(ImageView)vi.findViewById(R.id.list_image); // thumb image
        
        tipss = new HashMap<String, String>();
        tipss = data.get(position);
      
        // TODO Setting all values in list view
        id.setText(tipss.get(PencarianUmur.AR_ID));
        title.setText(tipss.get(PencarianUmur.AR_NAMA));
        keterangan.setText(tipss.get(PencarianUmur.AR_KETERANGAN));
        txtImage.setText(tipss.get(PencarianUmur.AR_IMAGE));
        
        String image = txtImage.getText().toString();
        if (image.equals("tanah_lot.png")) {
        	thumb_image.setImageResource(R.drawable.tanah_lot);
        } else if (image.equals("ubud.png")) {
        	thumb_image.setImageResource(R.drawable.ubud);
        } else if (image.equals("gold_coast.png")) {
        	thumb_image.setImageResource(R.drawable.gold_coast);
        } else if (image.equals("coach_tours_tasmania.png")) {
        	thumb_image.setImageResource(R.drawable.coach_tours_tasmania);
        } else if (image.equals("night_safari.png")) {
        	thumb_image.setImageResource(R.drawable.night_safari);
        } else if (image.equals("danau_toba.png")) {
        	thumb_image.setImageResource(R.drawable.danau_toba);
        } else if (image.equals("besakih.png")) {
        	thumb_image.setImageResource(R.drawable.besakih);
        } else if (image.equals("sea_aquarium.png")) {
        	thumb_image.setImageResource(R.drawable.sea_aquarium);
        } else if (image.equals("universal_studio.png")) {
        	thumb_image.setImageResource(R.drawable.universal_studio);
        }
        
        return vi;
    }
    
 // TODO Clear data on list view
    public void clearList() {
        data.clear();
        notifyDataSetChanged();
    }
}
