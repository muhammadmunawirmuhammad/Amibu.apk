package com.example.datewithme;



import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;



import android.app.ListActivity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.AdapterView.OnItemSelectedListener;

public class PencarianUmur extends ListActivity {
	private Spinner ikan, umur;
	private PU_DataIkan dbIkan;
	private PU_DataUmur dbUmur;
	private SQLiteDatabase db1 = null;
	private SQLiteDatabase db2 = null;
	public static final String AR_ID    = "Id";
	public static final String AR_NAMA  = "Nama";
	public static final String AR_IMAGE = "Image";
	public static final String AR_KETERANGAN = "Keterangan";
	
	ArrayList<HashMap<String, String>> daftar_list = new ArrayList<HashMap<String, String>>();
	
	private SQLiteDatabase db = null;
	private PU_DataUmurIkan dataDB = null;
	private Cursor cursor = null;
	
	private HashMap<String, String> mapp;
	private ListView list;
	private PU_UmurIkanAdapter adap;
	
	private String country, packet;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        
        dbIkan = new PU_DataIkan(this);
        db1 = dbIkan.getWritableDatabase();
        dbIkan.createTable(db1);
        dbIkan.generateData(db1);
        
        dbUmur = new PU_DataUmur(this);
        db2 = dbUmur.getWritableDatabase();
        dbUmur.createTable(db2);
        dbUmur.generateData(db2);
        
        dataDB = new PU_DataUmurIkan(this);
	    db = dataDB.getWritableDatabase();
	    dataDB.createTable(db);
	    dataDB.generateData(db);

        setContentView(R.layout.main_pu);
        
        isiDataSpinnerIkan();
        isiDataSpinnerUmur();
        getList();
        
        ikan.setOnItemSelectedListener(new OnItemSelectedListener(){
            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2,long arg3) {
            	country = ikan.getSelectedItem().toString();
            	adap.clearList();
				getList();
            }
            @Override
			public void onNothingSelected(AdapterView<?> arg0) { 
				// TODO Auto-generated method stub
				
			}
        });
        
        umur.setOnItemSelectedListener(new OnItemSelectedListener(){
            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2,long arg3) {
            	packet = umur.getSelectedItem().toString();
            	adap.clearList();
				getList();
            }
            @Override
			public void onNothingSelected(AdapterView<?> arg0) { 
				// TODO Auto-generated method stub
				
			}
        });
    }
    
    private void isiDataSpinnerIkan() {
    	ikan = (Spinner) findViewById(R.id.negara);
    	List<String> lables = dbIkan.getAllLabels();
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                R.layout.spinner_item, lables);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        ikan.setAdapter(dataAdapter);
    }
    
    private void isiDataSpinnerUmur() {
    	umur = (Spinner) findViewById(R.id.paket);
    	List<String> lables = dbUmur.getAllLabels();
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                R.layout.spinner_item, lables);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        umur.setAdapter(dataAdapter);
    	packet  = umur.getSelectedItem().toString();
    }
    
    public void getList() {
    	try {
		    cursor = db.rawQuery("SELECT * " + "FROM UmurIkan WHERE ikan = '" + country + "'" + " and umur = '" + packet + "';", null);
		    if (cursor.getCount() > 0) {
		    	int indexId         = cursor.getColumnIndex("id");
		    	int indexNama       = cursor.getColumnIndex("nama");
		    	int indexImage      = cursor.getColumnIndex("image");
		    	int indexKeterangan = cursor.getColumnIndex("keterangan");
		    	
		    	cursor.moveToFirst();
				do {
					String Id         = cursor.getString(indexId);
					String Nama       = cursor.getString(indexNama);
					String Image      = cursor.getString(indexImage);
					String Keterangan = cursor.getString(indexKeterangan);
					
					mapp = new HashMap<String, String>();
					mapp.put(AR_ID, Id);
					mapp.put(AR_NAMA, Nama);
					mapp.put(AR_IMAGE, Image);
					mapp.put(AR_KETERANGAN, Keterangan);
					
					daftar_list.add(mapp);
					
					cursor.moveToNext();
				} while (!cursor.isAfterLast());
		    }
	    } finally {
			if (cursor != null) {
				cursor.close();
			}
			
			this.adapter_listview();
		}
    }
    
    public void adapter_listview() {
		list = getListView();
		adap = new PU_UmurIkanAdapter(this, daftar_list);
        list.setAdapter(adap);
        
        list.setOnItemClickListener(new OnItemClickListener() {
        	@Override
			 public void onItemClick(AdapterView<?> parent, View view,int position, long id) {
				// TODO Auto-generated method stub
				String i = ((TextView) view.findViewById(R.id.id)).getText().toString();
				Intent in = new Intent(PencarianUmur.this, PU_DetailUmur.class);
				in.putExtra("ID", i);
				startActivity(in);
			}
		});
    }
    
    @Override
    public void onDestroy() {
    	super.onDestroy();
    	try {
    		db1.close();
    		db2.close();
    	} catch (Exception e) {
    	
    	}
    }

}
