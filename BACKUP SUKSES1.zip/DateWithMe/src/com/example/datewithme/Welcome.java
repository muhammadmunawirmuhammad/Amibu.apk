package com.example.datewithme;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Welcome extends Activity{
	
	public void infoikan(View v){
		Intent IK = new Intent(this, InfoIkan.class);
    	startActivity(IK);
	}
	public void pencarianumur(View v){
		Intent PU = new Intent(this, PencarianUmur.class);
    	startActivity(PU);
	}
	public void panen(View v){
		Intent PANEN = new Intent(this, MainPanen.class);
    	startActivity(PANEN);
	}
	public void hitungumur(View v){
		Intent HU = new Intent(this, HitungUmur.class);
    	startActivity(HU);
	}
	public void Keluar(View v){
		AlertDialog.Builder alerBuilder = new AlertDialog.Builder(this);
		alerBuilder.setTitle("Konfirmasi Aplikasi");
		alerBuilder.setMessage("Are you Sure ?");
		alerBuilder.setPositiveButton("YES", 
				new DialogInterface.OnClickListener() {
					
					@Override
					public void onClick(DialogInterface arg0, int arg1) {
						// TODO Auto-generated method stub
						finish();
					}
				});
		alerBuilder.setNegativeButton("NO", 
				new DialogInterface.OnClickListener() {
					
					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						dialog.cancel();
					}
				});
		alerBuilder.show();
	}
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.welcome);
	}
}
